// index.js
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("carousel-item");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {
        myIndex = 1;
    }
    x[myIndex - 1].style.display = "block";
    setTimeout(carousel, 5000); // Change slide every 10 seconds
}

function logout() {
    // Assuming index.php is in the same directory, change the path accordingly
    window.location.href = 'index.php?logout=true';
}

