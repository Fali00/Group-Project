<?php
if (session_status() == PHP_SESSION_NONE){ //If session not started, session start here
    session_start();
}
    $view = new stdClass();

if (isset($_POST['logout'])) {
   unset( $_SESSION['admin']);
   session_destroy();
}
if (isset($_POST['submit'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        if ($username === 'admin' && $password === 'password') {
            // Set the admin session variable
            $_SESSION['admin'] = true;
        }
        else {
            // Add an error message or handle the failed login attempt
            $view->error = 'Invalid username or password try again';
        }
    }
if (isset($_SESSION['admin']) && $_SESSION['admin']){
        require('home.php');
    }
    else {
        require('Views/login.phtml');
    }






