<?php
require ('Views/home.phtml');